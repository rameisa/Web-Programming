
// ===============================
// 1. IMAGE SLIDESHOW
// ===============================

let slideIndex = 0;

function showSlide(index) {

    let slides = document.querySelectorAll(".slide");

    // Agar current page par slideshow nahi hai
    if (slides.length === 0) {
        return;
    }

    if (index >= slides.length) {
        slideIndex = 0;
    }

    if (index < 0) {
        slideIndex = slides.length - 1;
    }

    slides.forEach(function(slide) {
        slide.classList.remove("active");
    });

    slides[slideIndex].classList.add("active");
}

function changeSlide(value) {
    slideIndex = slideIndex + value;
    showSlide(slideIndex);
}

function currentSlide(index) {
    slideIndex = index;
    showSlide(slideIndex);
}

// Automatic slideshow
if (document.querySelectorAll(".slide").length > 0) {
    showSlide(slideIndex);

    setInterval(function() {
        slideIndex++;
        showSlide(slideIndex);
    }, 3000);
}


// ===============================
// 2. PRODUCT FILTERING
// ===============================


function filterProducts() {

    let search = document.getElementById("searchInput").value.toLowerCase();

    let category = document.getElementById("categoryFilter").value;

    let price = document.getElementById("priceFilter").value;

    let brand = document.getElementById("brandFilter").value;

    let rating = document.getElementById("ratingFilter").value;

    let products = document.querySelectorAll(".product-card");

    products.forEach(function(product) {

        let name = product.querySelector("h3").innerText.toLowerCase();

        let priceText = product.querySelector("p").innerText;

        let productPrice = Number(priceText.replace(/[^0-9]/g, ""));

        let productCategory = product.dataset.category;

        let productBrand = product.dataset.brand;

        let productRating = Number(product.dataset.rating);

        let searchMatch = name.includes(search);

        let categoryMatch =
            category === "all" || category === "" ||
            category === productCategory;

        let priceMatch =
            price === "" || productPrice <= Number(price);

        let brandMatch =
            brand === "all" || brand === productBrand;

        let ratingMatch =
            rating === "all" || productRating >= Number(rating);

        if (
            searchMatch &&
            categoryMatch &&
            priceMatch &&
            brandMatch &&
            ratingMatch
        ) {
            product.style.display = "";
        } else {
            product.style.display = "none";
        }

    });
}


// Filter Event Listeners

let searchInput = document.getElementById("searchInput");
let categoryFilter = document.getElementById("categoryFilter");
let priceFilter = document.getElementById("priceFilter");
let brandFilter = document.getElementById("brandFilter");
let ratingFilter = document.getElementById("ratingFilter");

if (searchInput) {
    searchInput.addEventListener("input", filterProducts);
}

if (categoryFilter) {
    categoryFilter.addEventListener("change", filterProducts);
}

if (priceFilter) {
    priceFilter.addEventListener("input", filterProducts);
}

if (brandFilter) {
    brandFilter.addEventListener("change", filterProducts);
}

if (ratingFilter) {
    ratingFilter.addEventListener("change", filterProducts);
}


// ===============================
// 3. SHOPPING CART
// ===============================

// Get saved cart products
let cart = JSON.parse(localStorage.getItem("cart")) || [];


// Add product to cart
function addToCart(name, price) {

    let product = cart.find(function(item) {
        return item.name === name;
    });

    if (product) {
        product.quantity++;
    } else {
        cart.push({
            name: name,
            price: price,
            quantity: 1
        });
    }

    localStorage.setItem("cart", JSON.stringify(cart));

    updateCartCount();

    alert("Product added to cart successfully!");
}


// Update cart item count
function updateCartCount() {

    let count = 0;

    cart.forEach(function(product) {
        count += product.quantity;
    });

    let cartCount = document.getElementById("cartCount");

    if (cartCount) {
        cartCount.innerText = count;
    }
}


// Open cart page
function viewCart() {
    window.location.href = "cart.html";
}


// Display cart products

function displayCart() {

    let cartItems = document.getElementById("cartItems");
    let cartTotal = document.getElementById("cartTotal");

    if (!cartItems || !cartTotal) {
        return;
    }

    let total = 0;

    cartItems.innerHTML = "";

    if (cart.length === 0) {

        cartItems.innerHTML = "<p>Your cart is empty.</p>";
        cartTotal.innerText = "Total: Rs. 0";

        return;
    }

    cart.forEach(function(product, index) {

        let itemTotal = product.price * product.quantity;

        total += itemTotal;

        cartItems.innerHTML += `
            <div class="cart-item">

                <h3>${product.name}</h3>

                <p>Price: Rs. ${product.price}</p>

                <p>Quantity: ${product.quantity}</p>

                <p>Subtotal: Rs. ${itemTotal}</p>

                <button onclick="decreaseQuantity(${index})">-</button>

                <button onclick="increaseQuantity(${index})">+</button>

                <button onclick="removeProduct(${index})">Remove</button>

            </div>
        `;

    });

    cartTotal.innerText = "Total: Rs. " + total;

    updateCartCount();
}


// Increase product quantity
function increaseQuantity(index) {

    cart[index].quantity++;

    localStorage.setItem("cart", JSON.stringify(cart));

    displayCart();
}


// Decrease product quantity
function decreaseQuantity(index) {

    if (cart[index].quantity > 1) {

        cart[index].quantity--;

    } else {

        cart.splice(index, 1);

    }

    localStorage.setItem("cart", JSON.stringify(cart));

    displayCart();
}


// Remove product from cart
function removeProduct(index) {

    cart.splice(index, 1);

    localStorage.setItem("cart", JSON.stringify(cart));

    displayCart();

}


// ===============================
// 4. INITIAL PAGE UPDATES
// ===============================

updateCartCount();

displayCart();


// ===============================
// 5. PRODUCT DETAILS
// ===============================

function viewDetails(name, price) {

    let product = {
        name: name,
        price: price
    };

    localStorage.setItem(
        "selectedProduct",
        JSON.stringify(product)
    );

    window.location.href = "details.html";
}


// Display selected product details

function displayProductDetails() {

    let productDetails = document.getElementById("productDetails");

    if (!productDetails) {
        return;
    }

    let product = JSON.parse(
        localStorage.getItem("selectedProduct")
    );

    if (!product) {
        productDetails.innerHTML = "<p>No product selected.</p>";
        return;
    }

    let productImages = {
        "Wireless Headphones": "images/product1.jpg",
        "Smart Watch": "images/product2.jpg",
        "Sports Shoes": "images/product3.jpg",
        "Handbag": "images/product4.jpg",
        "Electric Blender": "images/product5.jpg"
    };

    let productDescriptions = {
        "Wireless Headphones": "Enjoy high quality sound with comfortable wireless headphones.",
        "Smart Watch": "A stylish smart watch with useful everyday features.",
        "Sports Shoes": "Comfortable sports shoes suitable for everyday activities.",
        "Handbag": "A stylish handbag for carrying your daily essentials.",
        "Electric Blender": "A useful kitchen blender for preparing different drinks."
    };

    let productImage = productImages[product.name];
    let description = productDescriptions[product.name];

    productDetails.innerHTML = `
        <div class="product-detail-card">

            <img src="${productImage}" alt="${product.name}">

            <h2>${product.name}</h2>

            <p>${description}</p>

            <h3>Price: Rs. ${product.price}</h3>

            <label>Quantity:</label>

            <input type="number" id="detailQuantity"
                   value="1" min="1">

            <br><br>

            <button onclick="addDetailProductToCart()">
                Add to Cart
            </button>

            <button onclick="viewCart()">
                Go to Cart
            </button>

        </div>
    `;
}


function addDetailProductToCart() {

    let quantity = parseInt(
        document.getElementById("detailQuantity").value
    );

    if (isNaN(quantity) || quantity < 1) {
        alert("Please enter a valid quantity!");
        return;
    }

    let product = JSON.parse(
        localStorage.getItem("selectedProduct")
    );

    for (let i = 0; i < quantity; i++) {
        addToCart(product.name, product.price);
    }

    alert("Product quantity added to cart!");
}

displayProductDetails();

// SIGNUP FUNCTION
let signupForm = document.getElementById("signupForm");

if (signupForm) {
    signupForm.addEventListener("submit", function(event) {
        event.preventDefault();

        let name = document.getElementById("signupName").value.trim();
        let email = document.getElementById("signupEmail").value.trim();
        let password = document.getElementById("signupPassword").value;
        let confirmPassword = document.getElementById("confirmPassword").value;

        if (password.length < 6) {
            alert("Password must contain at least 6 characters!");
        }
        else if (password !== confirmPassword) {
            alert("Password and Confirm Password do not match!");
        }
        else {
            let user = {
                name: name,
                email: email,
                password: password
            };

            localStorage.setItem("registeredUser", JSON.stringify(user));

            alert("Account created successfully!");
            signupForm.reset();

            window.location.href = "login.html";
        }
    });
}


// LOGIN FUNCTION
let loginForm = document.getElementById("loginForm");

if (loginForm) {
    loginForm.addEventListener("submit", function(event) {
        event.preventDefault();

        let email = document.getElementById("loginEmail").value.trim();
        let password = document.getElementById("loginPassword").value;

        let user = JSON.parse(localStorage.getItem("registeredUser"));

        if (!user) {
            alert("Please create an account first!");
        }
        else if (email === user.email && password === user.password) {
            localStorage.setItem("loggedInUser", JSON.stringify(user));

            alert("Login successful!");
            window.location.href = "profile.html";
        }
        else {
            alert("Invalid email or password!");
        }
    });
}


// Contact Form Validation
let contactForm = document.getElementById("contactForm");

if (contactForm) {
    contactForm.addEventListener("submit", function(event) {
        event.preventDefault();

        let name = document.getElementById("contactName").value;
        let email = document.getElementById("contactEmail").value;
        let subject = document.getElementById("contactSubject").value;
        let message = document.getElementById("contactMessage").value;

        if (name === "" || email === "" || subject === "" || message === "") {
            alert("Please fill all fields!");
        } else {
            alert("Your message has been submitted successfully!");
            contactForm.reset();
        }
    });
}


// Navigation Drawer Function
function toggleMenu() {
    let sideMenu = document.getElementById("sideMenu");

    if (sideMenu) {
        sideMenu.classList.toggle("active");
    }
}


// Wishlist Functionality
let wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];

function addToWishlist(name, price) {
    let product = wishlist.find(function(item) {
        return item.name === name;
    });

    if (product) {
        alert("This product is already in your Wishlist!");
    } else {
        wishlist.push({
            name: name,
            price: price
        });

        localStorage.setItem("wishlist", JSON.stringify(wishlist));

        alert("Product added to Wishlist successfully!");
    }
}


// Display Wishlist Products
function displayWishlist() {
    let wishlistItems = document.getElementById("wishlistItems");

    if (!wishlistItems) return;

    wishlistItems.innerHTML = "";

    if (wishlist.length === 0) {
        wishlistItems.innerHTML = "<p>Your Wishlist is empty.</p>";
        return;
    }

    wishlist.forEach(function(product, index) {
        wishlistItems.innerHTML += `
            <div class="wishlist-item">
                <h3>${product.name}</h3>
                <p>Price: Rs. ${product.price}</p>

                <button onclick="addToCart('${product.name}', ${product.price})">
                    Add to Cart
                </button>

                <button onclick="removeFromWishlist(${index})">
                    Remove
                </button>
            </div>
        `;
    });
}

// Remove Wishlist Product
function removeFromWishlist(index) {
    wishlist.splice(index, 1);

    localStorage.setItem("wishlist", JSON.stringify(wishlist));

    displayWishlist();
}

displayWishlist();


function displayProfile() {
    let profileInfo = document.getElementById("profileInfo");

    if (!profileInfo) return;

    let user = JSON.parse(localStorage.getItem("loggedInUser"));

    if (user) {
        profileInfo.innerHTML = `
            <h3>My Account Information</h3>
            <p><strong>Name:</strong> ${user.name}</p>
            <p><strong>Email:</strong> ${user.email}</p>
            <p><strong>Account:</strong> Registered Account</p>
        `;
    } else {
        profileInfo.innerHTML = `
            <p>Please login to view your profile.</p>
            <a href="login.html">Login Here</a>
        `;
    }
}

displayProfile();


function placeOrder() {

    let user = JSON.parse(localStorage.getItem("loggedInUser"));

    if (!user) {
        alert("Please login before placing an order!");
        window.location.href = "login.html";
        return;
    }

    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    let total = 0;

    cart.forEach(function(product) {
        total += product.price * product.quantity;
    });

    let orders = JSON.parse(localStorage.getItem("orders")) || [];

    let newOrder = {
        email: user.email,
        items: cart,
        total: total,
        date: new Date().toLocaleString()
    };

    orders.push(newOrder);

    localStorage.setItem("orders", JSON.stringify(orders));

    cart = [];
    localStorage.setItem("cart", JSON.stringify(cart));

    alert("Your order has been placed successfully!");

    displayCart();
}


function displayOrders() {

    let ordersList = document.getElementById("ordersList");

    if (!ordersList) return;

    let user = JSON.parse(localStorage.getItem("loggedInUser"));

    if (!user) {
        ordersList.innerHTML = `
            <p>Please login to view your orders.</p>
            <a href="login.html">Login Here</a>
        `;
        return;
    }

    let orders = JSON.parse(localStorage.getItem("orders")) || [];

    let userOrders = orders.filter(function(order) {
        return order.email === user.email;
    });

    if (userOrders.length === 0) {
        ordersList.innerHTML = "<p>No orders found yet.</p>";
        return;
    }

    ordersList.innerHTML = "";

    userOrders.forEach(function(order, index) {

        let itemsHTML = "";

        order.items.forEach(function(product) {
            itemsHTML += `
                <p>${product.name} - Quantity: ${product.quantity}</p>
            `;
        });

        ordersList.innerHTML += `
            <div class="order-card">
                <h3>Order #${index + 1}</h3>
                <p><strong>Date:</strong> ${order.date}</p>
                ${itemsHTML}
                <h3>Total: Rs. ${order.total}</h3>
                <p>Status: Order Placed</p>
            </div>
        `;
    });
}

displayOrders();


function logoutUser() {
    localStorage.removeItem("loggedInUser");

    alert("You have logged out successfully!");

    window.location.href = "login.html";
}


function selectCategory(category) {

    let categoryFilter = document.getElementById("categoryFilter");

    if (categoryFilter) {
        categoryFilter.value = category;

        filterProducts();

        document.getElementById("products").scrollIntoView({
            behavior: "smooth"
        });
    }
}
